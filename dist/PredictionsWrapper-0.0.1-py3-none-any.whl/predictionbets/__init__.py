from predictions import DogeBet
from predictions import CandleGenie
from predictions import PancakeSwap
